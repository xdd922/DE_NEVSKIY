﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DE_NEVSKIY
{
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
        }
        private void Knopka_Avtorizatii_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=XDD922;Initial Catalog=DentistClinic;Integrated Security=True"); //создание подключения с б.д
            SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) From Auth_Table Where Login ='" + Login_TextBox.Text + "' and Password = '" + Password_TextBox.Text + "'", con); //чтение введенных данных
            DataTable dt = new DataTable(); //Создание DataTable
            sda.Fill(dt); //Заполнение DataTable данными из выборки SqlDataAdapter
            if (dt.Rows[0][0].ToString() == "1")
            {
                if (Login_TextBox.Text == "Admin")
                {
                    Patienti clients = new Patienti();
                    clients.Show();
                    this.Hide();
                }    
            }
        }
    }
}
