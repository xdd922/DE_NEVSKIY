﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DE_NEVSKIY
{
    public partial class Patienti : Form
    {
        public Patienti()
        {
            InitializeComponent();
        }

        private void patientsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.patientsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dentistClinicDataSet);

        }

        private void Clienti_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dentistClinicDataSet.Patients". При необходимости она может быть перемещена или удалена.
            this.patientsTableAdapter.Fill(this.dentistClinicDataSet.Patients);

        }
        private System.Windows.Forms.DataGridViewColumn COL;
        private void button5_Click(object sender, EventArgs e)
        {
            {
                COL = new System.Windows.Forms.DataGridViewColumn();
                switch (listBox1.SelectedIndex)
                {
                    case 0:
                        COL = dataGridViewTextBoxColumn2;
                        break;
                    case 1:
                        COL = dataGridViewTextBoxColumn3;
                        break;
                    case 2:
                        COL = dataGridViewTextBoxColumn4;
                        break;
                    case 3:
                        COL = dataGridViewTextBoxColumn5;
                        break;
                    case 4:
                        COL = dataGridViewTextBoxColumn6;
                        break;
                }
                //Блок If выполняет следующую операцию: если включён
                //переключатель «Сортировка по возрастанию» (RadioButton1), то отсортировать
                //таблицу по полю заданному в переменной Col по возрастанию
                //(pRODUCTSDataGridView.Sort (Col, System.ComponentModel.ListSortDirection.
                //Ascending)), иначе по убыванию (pRODUCTSDataGridView.Sort (Col, System.
                //ComponentModel.ListSortDirection. Descending)).
                if (radioButton1.Checked)
                    patientsDataGridView.Sort(COL,
                   System.ComponentModel.ListSortDirection.Ascending);
                else
                    patientsDataGridView.Sort(COL,
                   System.ComponentModel.ListSortDirection.Descending);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                patientsBindingSource.Filter = "NAME='" + naimenovanie.Text + "'";
            }
        }

        private void Knopka_Pokazat_Vse_Click(object sender, EventArgs e)
        {
            {
                patientsBindingSource.Filter = "";
            }
        }

        private void Knopka_Naity_Click(object sender, EventArgs e)
        {
            //перебирает все ячейки таблицы и
            //устанавливает в них белый цвет фона и чёрный цвет текста, то есть,
            //отменяет результаты предыдущего поиска
            for (int i = 0; i < patientsDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < patientsDataGridView.RowCount - 1; j++)
                {
                    patientsDataGridView[i, j].Style.BackColor = Color.White;
                    patientsDataGridView[i, j].Style.ForeColor = Color.Black;
                }
            }
            //перебирает все ячейки таблицы и если они
            //содержат текст, введённый в поле ввода (TextBox1), то устанавливает в них
            //голубой цвет фона и синий цвет текста, чем выделяет искомые ячейки.
            for (int i = 0; i < patientsDataGridView.ColumnCount - 1; i++)
            {
                for (int j = 0; j < patientsDataGridView.RowCount - 1; j++)
                {
                    if (patientsDataGridView[i,
                   j].Value.ToString().IndexOf(kriteriy.Text) != -1)
                    {
                        patientsDataGridView[i, j].Style.BackColor = Color.AliceBlue;
                        patientsDataGridView[i, j].Style.ForeColor = Color.Blue;

                    }
                }
            }
        }

        private void Knopka_Zakrit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
